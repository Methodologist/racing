-- RemoteGenerator.lua
-- Ensures all required RemoteEvents and RemoteFunctions exist in ReplicatedStorage/Remotes

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local function ensureFolder(parent, name)
	local folder = parent:FindFirstChild(name)
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local RemotesFolder = ensureFolder(ReplicatedStorage, "Remotes")

local function ensureRemoteEvent(name)
	local remote = RemotesFolder:FindFirstChild(name)
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = RemotesFolder
	end
	return remote
end

local function ensureRemoteFunction(name)
	local remote = RemotesFolder:FindFirstChild(name)
	if not remote then
		remote = Instance.new("RemoteFunction")
		remote.Name = name
		remote.Parent = RemotesFolder
	end
	return remote
end

local RemoteGenerator = {}

RemoteGenerator.Events = {
	"RaceCountdown",
	"RaceGo",
	"ApplyBoost",
	"RaceFinished",
}

RemoteGenerator.Functions = {
	"RequestKartSpawn",
}

function RemoteGenerator.GenerateAll()
	for _, name in ipairs(RemoteGenerator.Events) do
		ensureRemoteEvent(name)
	end
	for _, name in ipairs(RemoteGenerator.Functions) do
		ensureRemoteFunction(name)
	end
end

return RemoteGenerator
