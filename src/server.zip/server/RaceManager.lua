-- src/server/RaceManager.lua
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local RaceManager = {}
RaceManager.State = "Waiting"

local COUNTDOWN_TIME = 3
local LAPS = 3

-- FIX: Use the 'Shared' folder name defined in your default.project.json
local Shared = ReplicatedStorage:WaitForChild("Shared")
local CheckpointService = require(Shared:WaitForChild("CheckpointService"))
local KartConfig = require(Shared:WaitForChild("KartConfig"))

local checkpoints = nil
local checkpointService = nil
local playerBoosts = {}

-- FIX: Remotes are inside the Shared folder per your Remotes.lua script
local Remotes = require(Shared:WaitForChild("Remotes"))

local function fireRemote(remoteEvent, ...)
    if remoteEvent then
        remoteEvent:FireAllClients(...)
    end
end

function RaceManager.StartRace(mapName: string)
    RaceManager.State = "Countdown"
    
    local MapLoader = require(script.Parent.MapLoader)
    local mapModel = MapLoader.Load(mapName)
    
    if not mapModel then
        warn("CRITICAL: Map " .. mapName .. " failed to load!")
        return 
    end
    
    checkpoints = {}
    for _, obj in ipairs(mapModel:GetDescendants()) do
        -- Matches 'Checkpoint', 'Checkpoint1', etc.
        if string.find(obj.Name, "Checkpoint") and obj:IsA("BasePart") then
            table.insert(checkpoints, obj)
        end
    end

    -- ERROR PREVENTION: Stop if no checkpoints were found
    if #checkpoints == 0 then
        warn("CRITICAL: No parts named 'Checkpoint' found in " .. mapName)
        RaceManager.State = "Waiting"
        return
    end
    
    table.sort(checkpoints, function(a, b) return a.Name < b.Name end)
    checkpointService = CheckpointService.new(checkpoints, LAPS)

    for _, player in ipairs(Players:GetPlayers()) do
        checkpointService:InitPlayer(player)
        playerBoosts[player] = {inputs = {}, lastInput = 0, boostCount = 0}
        
        -- FORCE SPAWN: If KartSpawner isn't automatic, call it here
        local KartSpawner = require(script.Parent.KartSpawner)
        if KartSpawner.setupKartForPlayer then
            KartSpawner.setupKartForPlayer(player)
        end
    end

    -- ... rest of countdown code

    for i = COUNTDOWN_TIME, 1, -1 do
        fireRemote(Remotes.RaceCountdown, i)
        task.wait(1)
    end
    
    fireRemote(Remotes.RaceGo)
    RaceManager.State = "Racing"

    -- Triple Boost Monitoring
    task.spawn(function()
        while RaceManager.State == "Racing" do
            for _, player in ipairs(Players:GetPlayers()) do
                local boost = playerBoosts[player]
                if boost and boost.boostCount < 3 then
                    local now = tick()
                    -- Logic for checking windows from KartConfig
                end
            end
            task.wait(0.05)
        end
    end)
end

return RaceManager