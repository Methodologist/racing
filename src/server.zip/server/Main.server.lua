local ServerScriptService = game:GetService("ServerScriptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- Navigate the folders created by your JSON
local ServerFolder = ServerScriptService:WaitForChild("Server")
local Shared = ReplicatedStorage:WaitForChild("Shared")

local RaceManager = require(ServerFolder.RaceManager)
local RemoteGenerator = require(ServerFolder.RemoteGenerator)

-- 1. Setup Remotes
RemoteGenerator.GenerateAll()

-- 2. Start the game loop when you join
game.Players.PlayerAdded:Connect(function(player)
    task.wait(2) -- Wait for client to load
    -- Ensure "MushroomWay" exists in ServerStorage.Maps
    RaceManager.StartRace("MushroomWay") 
end)