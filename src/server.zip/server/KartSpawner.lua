local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local KartSpawner = {} -- THIS FIXES THE CRASH: We actually create the table!

local KART_MODEL_NAME = "KartTemplate"

function KartSpawner.setupKartForPlayer(player, spawnCFrame)
    local template = ServerStorage:FindFirstChild(KART_MODEL_NAME)
    if not template then
        warn("Kart template not found in ServerStorage!")
        return
    end
    
    local kart = template:Clone()
    kart.Name = player.Name .. "_Kart"
    kart.PrimaryPart = kart.PrimaryPart or kart:FindFirstChildWhichIsA("BasePart")
    
    -- Spawn exactly where the RaceManager tells us to
    local finalCFrame = spawnCFrame or CFrame.new(0, 10, 0)
    kart:SetPrimaryPartCFrame(finalCFrame)
    kart.Parent = Workspace

    -- ⚖️ UPDATED MASSLESS KART FIX (Prevents Physics Clamping & Anchoring)
    for _, part in ipairs(kart:GetDescendants()) do
        if part:IsA("BasePart") then
            -- 🟢 FIX: Unanchor everything so physics can take over
            part.Anchored = false 
            
            if part ~= kart.PrimaryPart then
                part.Massless = true
                if part.Name ~= "Wheel" then
                    part.CustomPhysicalProperties = PhysicalProperties.new(0.01, 0, 0, 0, 0)
                end
            end
        end
    end
    
    -- NETWORK OWNERSHIP
    if kart.PrimaryPart and kart.PrimaryPart:CanSetNetworkOwnership() then
        kart.PrimaryPart:SetNetworkOwner(player)
    end
    
    local character = player.Character or player.CharacterAdded:Wait()
    local humanoid = character:WaitForChild("Humanoid")
    
    -- MASSLESS CHARACTER
    for _, part in ipairs(character:GetDescendants()) do
        if part:IsA("BasePart") then
            part.Massless = true
        end
    end
    
    local driveSeat = kart:FindFirstChild("DriveSeat", true) or kart:FindFirstChildWhichIsA("VehicleSeat", true)
    
    if driveSeat then
        task.wait(0.1)
        driveSeat:Sit(humanoid)
        
        -- Lock the player in the kart
        humanoid.UseJumpPower = true
        humanoid.JumpPower = 0

        -- 🏷️ INSERT THE NEW OVERHEAD UI HERE
        local head = character:WaitForChild("Head")
        local billboard = Instance.new("BillboardGui")
        billboard.Name = "RaceStatusUI"
        billboard.Adornee = head
        billboard.Size = UDim2.new(0, 200, 0, 50)
        billboard.StudsOffset = Vector3.new(0, 4, 0) -- Sits 4 studs above the head
        billboard.AlwaysOnTop = true 
        billboard.MaxDistance = 500 -- Visible from far away
        
        local nameLabel = Instance.new("TextLabel", billboard)
        nameLabel.Name = "PlayerName"
        nameLabel.Size = UDim2.new(1, 0, 0.5, 0)
        nameLabel.BackgroundTransparency = 1
        nameLabel.Text = player.Name
        nameLabel.TextColor3 = Color3.new(1, 1, 1)
        nameLabel.TextStrokeTransparency = 0
        nameLabel.Font = Enum.Font.GothamBold
        nameLabel.TextScaled = true
        
        local placeLabel = Instance.new("TextLabel", billboard)
        placeLabel.Name = "PlaceLabel"
        placeLabel.Size = UDim2.new(1, 0, 0.5, 0)
        placeLabel.Position = UDim2.new(0, 0, 0.5, 0)
        placeLabel.BackgroundTransparency = 1
        placeLabel.Text = "WAITING..."
        placeLabel.TextColor3 = Color3.fromRGB(255, 215, 0) -- Gold
        placeLabel.TextStrokeTransparency = 0
        placeLabel.Font = Enum.Font.GothamBlack
        placeLabel.TextScaled = true
        
        billboard.Parent = head
    else
        warn("CRITICAL ERROR: No VehicleSeat found!")
    end
    
    return kart
end

return KartSpawner