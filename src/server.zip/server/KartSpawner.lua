-- KartSpawner.lua
-- Spawns a kart for each player, sets name and PrimaryPart

local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local KART_MODEL_NAME = "KartTemplate" -- Place your kart model in ServerStorage with this name

local spawnIndex = 1
local function getNextSpawn()
	local spawns = {}
	for _, obj in ipairs(Workspace:GetDescendants()) do
		if obj:IsA("SpawnLocation") then
			table.insert(spawns, obj)
		end
	end
	if #spawns == 0 then return CFrame.new(0, 5, 0) end
	local spawn = spawns[spawnIndex]
	spawnIndex = (spawnIndex % #spawns) + 1
	return spawn.CFrame + Vector3.new(0, 3, 0)
end

local function setupKartForPlayer(player)
	local template = ServerStorage:FindFirstChild(KART_MODEL_NAME)
	if not template then
		warn("Kart template not found in ServerStorage: " .. KART_MODEL_NAME)
		return
	end
	local kart = template:Clone()
	kart.Name = player.Name .. "_Kart"
	if not kart.PrimaryPart then
		local primary = kart:FindFirstChildWhichIsA("BasePart")
		if primary then
			kart.PrimaryPart = primary
		else
			warn("No BasePart found in kart model for PrimaryPart!")
			return
		end
	end
	-- Place at next available spawn location
	kart:SetPrimaryPartCFrame(getNextSpawn())
	kart.Parent = Workspace
end

Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(function()
		setupKartForPlayer(player)
	end)
end)

-- For studio testing, spawn for all players on script run
for _, player in ipairs(Players:GetPlayers()) do
	if player.Character then
		setupKartForPlayer(player)
	end
end

return KartSpawner