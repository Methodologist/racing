-- KartController.client.lua
-- Handles input, raycast suspension, drift, air control

local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local LocalPlayer = Players.LocalPlayer

-- Use correct path for KartConfig
local KartConfig = require(ReplicatedStorage.Shared:WaitForChild("KartConfig"))

-- Placeholder: assign kart and root after spawn
local kart = nil -- The player's kart model
local root = nil -- The PrimaryPart of the kart

-- Example: wait for kart to appear in workspace (customize as needed)
local function waitForKart()
	-- Replace this logic with your own kart spawning/assignment
	local timeout = 10
	local t0 = tick()
	while tick() - t0 < timeout do
		local candidate = Workspace:FindFirstChild(LocalPlayer.Name .. "_Kart")
		if candidate and candidate.PrimaryPart then
			kart = candidate
			root = candidate.PrimaryPart
			break
		end
		task.wait(0.2)
	end
end

local driftState = false
local driftDirection = 0
local airborne = false
local driftStart = 0
local driftBoostReady = false

local function getInput()
	local move = 0
	local steer = 0
	if UserInputService:IsKeyDown(Enum.KeyCode.W) then move = 1 end
	if UserInputService:IsKeyDown(Enum.KeyCode.S) then move = -1 end
	if UserInputService:IsKeyDown(Enum.KeyCode.A) then steer = -1 end
	if UserInputService:IsKeyDown(Enum.KeyCode.D) then steer = 1 end
	return move, steer
end

local function applySuspension()
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Blacklist
	params.FilterDescendantsInstances = {kart}
	for name, offset in pairs(KartConfig.WheelOffset) do
		local origin = root.Position + root.CFrame:VectorToWorldSpace(offset)
		local direction = Vector3.new(0, -1, 0) * KartConfig.SuspensionLength
		local result = Workspace:Raycast(origin, direction, params)

		if result then
			local compression = KartConfig.SuspensionLength - (origin.Y - result.Position.Y)
			local force = compression * KartConfig.SuspensionStiffness - root.AssemblyLinearVelocity.Y * KartConfig.SuspensionDamping
			root:ApplyImpulse(Vector3.new(0, force, 0))
			-- Surface alignment
			if name == "FrontLeft" then
				local normal = result.Normal
				local up = root.CFrame.UpVector
				local axis = up:Cross(normal)
				local angle = math.acos(math.clamp(up:Dot(normal), -1, 1))
				if angle > 0.01 then
					root:ApplyAngularImpulse(axis.Unit * angle * 0.5)
				end
			end
		end
	end
end

local function applyDrive(move, steer)
	local forward = root.CFrame.LookVector
	local right = root.CFrame.RightVector
	local velocity = root.AssemblyLinearVelocity
	local speed = velocity:Dot(forward)
	local lateral = velocity:Dot(right)

	-- Acceleration
	if move ~= 0 then
		local accel = forward * move * KartConfig.Acceleration * RunService.RenderStepped:Wait()
		root:ApplyImpulse(accel)
	end

	-- Steering
	if not airborne then
		local steerAmount = steer * (driftState and 1.5 or 1)
		root:ApplyAngularImpulse(Vector3.new(0, steerAmount * 0.08, 0))
	end

	-- Friction
	local friction = driftState and KartConfig.DriftFriction or KartConfig.NormalFriction
	local lateralFriction = -right * lateral * friction
	root:ApplyImpulse(lateralFriction)
end

local function handleDriftInput()
	-- Inside handleDriftInput, detect a "boost" key (like Shift or W tap)
    UserInputService.InputBegan:Connect(function(input, processed)
        if processed then return end
        if input.KeyCode == Enum.KeyCode.W then
            -- Tell the server we are attempting a timed boost
            local Remotes = require(ReplicatedStorage.Shared.Remotes)
            Remotes.ApplyBoost:FireServer() 
        end
    end)
	UserInputService.InputEnded:Connect(function(input)
		if input.KeyCode == Enum.KeyCode.Space and driftState then
			driftState = false
			if tick() - driftStart > 0.5 then
				driftBoostReady = true
			end
		end
	end)
end

local function applyDriftBoost()
	if driftBoostReady then
		root:ApplyImpulse(root.CFrame.LookVector * KartConfig.DriftBoostPower)
		driftBoostReady = false
	end
end

local function applyAirControl()
	if airborne then
		local pitch = 0
		local yaw = 0
		if UserInputService:IsKeyDown(Enum.KeyCode.W) then pitch = 1 end
		if UserInputService:IsKeyDown(Enum.KeyCode.S) then pitch = -1 end
		if UserInputService:IsKeyDown(Enum.KeyCode.A) then yaw = -1 end
		if UserInputService:IsKeyDown(Enum.KeyCode.D) then yaw = 1 end
		local torque = Vector3.new(pitch, 0, yaw) * KartConfig.AirControlTorque
		root:ApplyAngularImpulse(torque)
	end
end

local function updateAirborne()
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Blacklist
	params.FilterDescendantsInstances = {kart}
	local ray = Workspace:Raycast(root.Position, Vector3.new(0, -1, 0) * (KartConfig.SuspensionLength + 1), params)
	airborne = not ray
end

local function onHeartbeat()
	if not kart or not root then return end
	local move, steer = getInput()
	updateAirborne()
	applySuspension()
	applyDrive(move, steer)
	applyAirControl()
	applyDriftBoost()
end

local function init()
	waitForKart()
	if not kart or not root then
		warn("Kart not found for player! Make sure kart is spawned and named '<PlayerName>_Kart' with PrimaryPart set.")
		return
	end
	handleDriftInput()
	RunService.Heartbeat:Connect(onHeartbeat)
end

init()

return {}
